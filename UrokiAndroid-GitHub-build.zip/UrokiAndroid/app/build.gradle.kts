plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.uroki.widget"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.uroki.widget"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
