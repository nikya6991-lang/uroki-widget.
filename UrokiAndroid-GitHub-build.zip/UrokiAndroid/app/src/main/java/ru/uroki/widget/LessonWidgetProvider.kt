package ru.uroki.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private data class Lesson(val start: String, val end: String, val room: String, val subject: String) {
    fun startCal(day: Calendar) = at(day, start)
    fun endCal(day: Calendar) = at(day, end)
}

class LessonWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
        scheduleNext(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_UPDATE) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, LessonWidgetProvider::class.java))
            ids.forEach { updateOne(context, manager, it) }
            scheduleNext(context)
        }
    }

    companion object {
        private const val ACTION_UPDATE = "ru.uroki.widget.UPDATE"
        private val schedule = mapOf(
            Calendar.MONDAY to listOf(
                Lesson("08:30", "09:15", "310", "Разговоры о важном"), Lesson("09:30", "10:15", "301", "Иностранный (английский) язык"),
                Lesson("10:35", "11:20", "312", "Алгебра"), Lesson("11:40", "12:25", "312", "Алгебра"), Lesson("12:40", "13:25", "214", "История"),
                Lesson("13:45", "14:30", "120", "Русский язык"), Lesson("14:45", "15:30", "204", "География")),
            Calendar.TUESDAY to listOf(
                Lesson("08:30", "09:15", "312", "Геометрия"), Lesson("09:30", "10:15", "312", "Геометрия"), Lesson("10:35", "11:20", "120", "Русский язык"),
                Lesson("11:40", "12:25", "120", "Литература"), Lesson("12:40", "13:25", "205", "Химия"), Lesson("13:45", "14:30", "304", "Физика"), Lesson("14:45", "15:30", "214", "История")),
            Calendar.WEDNESDAY to listOf(
                Lesson("08:30", "09:15", "304", "Физика"), Lesson("09:30", "10:15", "310", "Вероятность и статистика"), Lesson("10:35", "11:20", "120", "Литература"),
                Lesson("11:40", "12:25", "407", "Биология"), Lesson("12:40", "13:25", "301", "Иностранный (английский) язык"), Lesson("13:45", "14:30", "312", "Алгебра"), Lesson("14:45", "15:30", "312", "Алгебра")),
            Calendar.THURSDAY to listOf(
                Lesson("08:30", "09:15", "210", "Физическая культура"), Lesson("09:30", "10:15", "205", "Химия"), Lesson("10:35", "11:20", "407", "Биология"),
                Lesson("11:40", "12:25", "304", "Физика"), Lesson("12:40", "13:25", "120", "Русский язык"), Lesson("13:45", "14:30", "120", "Литература"), Lesson("14:45", "15:30", "104", "Обществознание")),
            Calendar.FRIDAY to listOf(
                Lesson("08:30", "09:15", "308", "Основы безопасности и защиты Родины"), Lesson("09:30", "10:15", "103", "Труд (технология)"), Lesson("10:35", "11:20", "312", "Геометрия"),
                Lesson("11:40", "12:25", "301", "Иностранный (английский) язык"), Lesson("12:40", "13:25", "304", "Информатика"), Lesson("13:45", "14:30", "204", "География"))
        )

        private fun at(day: Calendar, hm: String): Calendar = (day.clone() as Calendar).apply {
            val p = hm.split(":"); set(Calendar.HOUR_OF_DAY, p[0].toInt()); set(Calendar.MINUTE, p[1].toInt()); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }

        private fun nextSchoolDay(from: Calendar): Pair<Calendar, List<Lesson>>? {
            for (i in 1..7) {
                val d = (from.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, i) }
                val ls = schedule[d.get(Calendar.DAY_OF_WEEK)]
                if (ls != null) return d to ls
            }
            return null
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val now = Calendar.getInstance()
            val dayLessons = schedule[now.get(Calendar.DAY_OF_WEEK)] ?: emptyList()
            val nowMs = now.timeInMillis
            val views = RemoteViews(context.packageName, R.layout.widget_lesson)
            val timeFmt = SimpleDateFormat("HH:mm", Locale("ru"))
            val dateFmt = SimpleDateFormat("EEEE, d MMMM", Locale("ru"))
            views.setTextViewText(R.id.widget_clock, timeFmt.format(Date(nowMs)))
            views.setTextViewText(R.id.widget_date, dateFmt.format(Date(nowMs)).replaceFirstChar { it.uppercase(Locale("ru")) })
            views.setOnClickPendingIntent(R.id.widget_root, PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))

            var active: Lesson? = null
            var next: Lesson? = null
            var startMs = 0L
            var endMs = 0L
            var state = ""
            var headline = ""
            var upcomingText = ""
            var accent = 0xFF5E9FE8.toInt()

            for (i in dayLessons.indices) {
                val lesson = dayLessons[i]
                val s = lesson.startCal(now).timeInMillis
                val e = lesson.endCal(now).timeInMillis
                val following = dayLessons.getOrNull(i + 1)
                val nextStart = following?.startCal(now)?.timeInMillis
                if (nowMs in s until e) {
                    active = lesson; next = following; startMs = s; endMs = e
                    state = "ИДЁТ УРОК ${i + 1} ИЗ ${dayLessons.size}"; headline = lesson.subject
                    upcomingText = if (following != null) "Далее: ${following.subject} · каб. ${following.room} · ${following.start}" else "Последний урок сегодня"
                    break
                }
                if (following != null && nowMs in e until nextStart!!) {
                    active = following; next = following; startMs = e; endMs = nextStart
                    state = if (i + 1 == 3) "ЗАВТРАК" else if (i + 1 == 5) "ОБЕД" else "ПЕРЕМЕНА"
                    headline = "До следующего урока"; accent = if (i + 1 == 3 || i + 1 == 5) 0xFFDE9255.toInt() else 0xFF72BC8F.toInt()
                    upcomingText = "Следующий: ${following.subject} · каб. ${following.room} · ${following.start}"
                    break
                }
            }

            if (dayLessons.isNotEmpty() && active == null && nowMs < dayLessons.first().startCal(now).timeInMillis) {
                val first = dayLessons.first(); active = first; startMs = nowMs; endMs = first.startCal(now).timeInMillis
                state = "ДО УРОКОВ"; headline = "Первый урок: ${first.subject}"; upcomingText = "Кабинет ${first.room} · ${first.start}"
            }
            if (active == null) {
                val upcoming = nextSchoolDay(now)
                accent = 0xFF72BC8F.toInt()
                state = if (dayLessons.isEmpty()) "ВЫХОДНОЙ" else "УРОКИ ЗАВЕРШЕНЫ"
                headline = if (dayLessons.isEmpty()) "Сегодня выходной" else "Все уроки на сегодня завершены!"
                upcomingText = upcoming?.let { "${if (it.first.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR) + 1) "Завтра" else "Далее"}: ${it.second.first().subject} · каб. ${it.second.first().room} · ${it.second.first().start}" } ?: ""
            }

            views.setTextViewText(R.id.widget_status, state)
            views.setTextViewText(R.id.widget_subject, headline)
            views.setTextViewText(R.id.widget_room, if (active != null && state.startsWith("ИДЁТ")) "Кабинет ${active.room} · ${active.start}–${active.end}" else "")
            views.setTextViewText(R.id.widget_next, upcomingText)
            views.setTextColor(R.id.widget_status, accent)
            views.setTextColor(R.id.widget_timer, accent)
            val timerLabel = when {
                state.startsWith("ИДЁТ") -> "До конца урока"
                state == "ПЕРЕМЕНА" || state == "ЗАВТРАК" || state == "ОБЕД" -> "До следующего урока"
                state == "ДО УРОКОВ" -> "До начала первого урока"
                else -> ""
            }
            views.setTextViewText(R.id.widget_timer_label, timerLabel)
            if (endMs > nowMs && timerLabel.isNotEmpty()) {
                views.setChronometer(R.id.widget_timer, SystemClock.elapsedRealtime() + (endMs - nowMs), "%s", true)
                views.setViewVisibility(R.id.widget_timer, android.view.View.VISIBLE)
            } else {
                views.setViewVisibility(R.id.widget_timer, android.view.View.GONE)
            }
            manager.updateAppWidget(id, views)
        }

        private fun scheduleNext(context: Context) {
            val now = Calendar.getInstance()
            var nextAt = now.timeInMillis + 30 * 60 * 1000L
            for (offset in 0..7) {
                val day = (now.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, offset) }
                val lessons = schedule[day.get(Calendar.DAY_OF_WEEK)] ?: continue
                val boundaries = lessons.flatMap { listOf(it.startCal(day).timeInMillis, it.endCal(day).timeInMillis) }
                val future = boundaries.filter { it > now.timeInMillis }.minOrNull()
                if (future != null) { nextAt = future + 1000L; break }
            }
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, LessonWidgetProvider::class.java).setAction(ACTION_UPDATE)
            val pending = PendingIntent.getBroadcast(context, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            alarm.setAndAllowWhileIdle(AlarmManager.RTC, nextAt, pending)
        }
    }
}
