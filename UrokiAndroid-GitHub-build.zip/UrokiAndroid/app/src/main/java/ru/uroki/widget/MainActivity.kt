package ru.uroki.widget

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = TextView(this).apply {
            text = "Уроки\n\nЧтобы добавить виджет: удерживай палец на свободном месте главного экрана → Виджеты → Уроки.\n\nВиджет показывает текущий урок, кабинет, таймер и следующий урок. Расписание взято из исходного HTML."
            textSize = 18f
            setTextColor(android.graphics.Color.WHITE)
            setBackgroundColor(android.graphics.Color.rgb(25, 25, 25))
            setPadding(28, 36, 28, 28)
        }
        setContentView(text)
    }
}
